'''
Exercise 10-8-1
'''

def has_duplicates(lst):
    i=0
    while i<len(lst)-1:
        if lst[i] in lst[i+1:]:
            return True
        i+=1
    return False

n = int(raw_input('n = '))
l = []
print 'Enter '+ `n` +' numbers:'
for i in range(n):
    v = int(raw_input())
    l.append(v)
print has_duplicates(l)
